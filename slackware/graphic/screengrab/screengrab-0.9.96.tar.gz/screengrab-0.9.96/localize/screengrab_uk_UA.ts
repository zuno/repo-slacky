<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="uk">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/ui/about.cpp" line="37"/>
        <source>built on </source>
        <translation>дата збірки </translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="42"/>
        <source>using Qt </source>
        <translation>використовує Qt </translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="53"/>
        <source>About</source>
        <translation>Про програму</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="54"/>
        <source>Thanks</source>
        <translation>Подяки</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="111"/>
        <source>is crossplatform application for fast creation screenshots of your desktop.</source>
        <translation>кросплатформна програма для швидкого створення скріншотів.</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="123"/>
        <source>Licensed under the </source>
        <translation>За ліцензією </translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="116"/>
        <location filename="../src/ui/about.cpp" line="145"/>
        <source>E-Mail</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="55"/>
        <source>Help us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="113"/>
        <source>It&apos;s a light and powerfull application and had been written using Qt, so you can to use in Windows and Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="119"/>
        <source>Web site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="127"/>
        <source>Copyright &amp;copy; 2009-2012, Artem &apos;DOOMer&apos; Galichkin</source>
        <translation type="unfinished">Авторські права &amp;copy; 2009-2011, Артем &apos;DOOMer&apos; Галічкін {2009-2010,?} {2009-2012,?}</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="134"/>
        <source>You can join us and help us if you want, is an invitation if you like this application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="137"/>
        <source>What you can do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="140"/>
        <source>Translate to other language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="141"/>
        <source>Make suggestions for next releases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="142"/>
        <source>Report bugs and issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="149"/>
        <source>Bug tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="159"/>
        <source>Translate:</source>
        <translation>Переклади:</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="161"/>
        <source> Brazilian Portuguese translation</source>
        <translation>Бразильська португальська локалізація</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="162"/>
        <source>Marcio Moraes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="164"/>
        <source> Ukrainian translation</source>
        <translation> Український переклад</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="165"/>
        <source>Gennadi Motsyo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="167"/>
        <source> Spanish translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="168"/>
        <source>Burjans L GarcÃ­a D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="170"/>
        <source> Italian translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="174"/>
        <source>Testing:</source>
        <translation>Тестування:</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="176"/>
        <source>Dual monitor support and other in Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="177"/>
        <source>Dual monitor support in Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="178"/>
        <source>win32-build [Windows XP and 7]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="179"/>
        <source>old win32-build [Windows Vista]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="180"/>
        <source>win32-build [Windows 7]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="323"/>
        <location filename="../src/ui/configwidget.cpp" line="332"/>
        <source>Select directory</source>
        <translation>Вибір теки</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="345"/>
        <source>Do you want reset settings to defaults?</source>
        <translation>Ви хочете скинути налаштування за замовчуванням?</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="228"/>
        <location filename="../src/ui/configwidget.cpp" line="346"/>
        <source>Warning</source>
        <translation>Попередження</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="227"/>
        <source>Directory %1 does not exists. Do you eant to create it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="364"/>
        <source>None</source>
        <translation>Немає</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="412"/>
        <source>Example: </source>
        <translation>Приклад: </translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="473"/>
        <source>This keys is used in your system! Please select other keys</source>
        <translation>Ця комбінація вже задіяна в Вашій системі! Виберіть іншу</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="481"/>
        <source>This keys is used in ScreenGrab! Please select other keys</source>
        <translation>Ця комбінація вже задіяна в ScreenGrab! Виберіть іншу</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="501"/>
        <source>This key is not supported on your system!</source>
        <translation>Ця комбінація не підтримується вашою системою!</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="538"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../src/core/core.cpp" line="183"/>
        <source>New screen</source>
        <translation>Новий скріншот</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="183"/>
        <source>New screen is getted!</source>
        <translation>Новий знімок отримано!</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="400"/>
        <source>Saved</source>
        <translation>Збережено</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="432"/>
        <source>Name of saved file is copied to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="438"/>
        <source>Path to saved file is copyed to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="451"/>
        <source>Copied</source>
        <translation>Скопійовано</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="400"/>
        <source>Saved to </source>
        <translation>Збережено до</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="451"/>
        <source>Screenshot is copied to clipboard</source>
        <translation>Скріншот скопійовано до кишені</translation>
    </message>
</context>
<context>
    <name>DialogUploader</name>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="14"/>
        <source>Publish to internet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="22"/>
        <source>Upload to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="73"/>
        <source>Direct link:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="95"/>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="133"/>
        <source>Copy</source>
        <translation type="unfinished">Копіювати</translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="106"/>
        <source>Extended preformed html or bb codes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="183"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="241"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="254"/>
        <source>Close</source>
        <translation type="unfinished">Закрити</translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="54"/>
        <source>Size: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="54"/>
        <source> pixel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="63"/>
        <source>Uploaded </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="66"/>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="212"/>
        <source>Ready to upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="106"/>
        <source>Upload preocessing... Please wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="170"/>
        <source>Receiving a response from the server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="192"/>
        <source>Upload completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="206"/>
        <source>Error uploading screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="207"/>
        <source>Error</source>
        <translation type="unfinished">Помилка</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="303"/>
        <source>Quit</source>
        <translation>Вихід</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="304"/>
        <source>Save</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="305"/>
        <source>New</source>
        <translation>Новий</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="306"/>
        <source>Copy</source>
        <translation>Копіювати</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="307"/>
        <location filename="../src/ui/mainwindow.cpp" line="438"/>
        <location filename="../src/ui/mainwindow.cpp" line="468"/>
        <source>Hide</source>
        <translation>Сховати вікно</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="353"/>
        <location filename="../src/ui/mainwindow.cpp" line="308"/>
        <source>About</source>
        <translation>Про програму</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="558"/>
        <source>PNG Files</source>
        <translation>файли PNG</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="559"/>
        <source>JPEG Files</source>
        <translation>файли JPEG</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="560"/>
        <source>BMP Files</source>
        <translation>файли BMP</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="303"/>
        <location filename="../src/ui/mainwindow.cpp" line="309"/>
        <source>Options</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="372"/>
        <source>None</source>
        <translation>Немає</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="445"/>
        <source>Show</source>
        <translation>Показати вікно</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="591"/>
        <location filename="../src/ui/mainwindow.cpp" line="595"/>
        <location filename="../src/ui/mainwindow.cpp" line="599"/>
        <source>Save As...</source>
        <translation>Зберегти як...</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="20"/>
        <source>ScreenGrab</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="83"/>
        <source>Type: </source>
        <translation>Тип: </translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="96"/>
        <source>Type of screenshot</source>
        <translation>Тип скріншоту</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="103"/>
        <source>Full screen</source>
        <translation>Весь екран</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="108"/>
        <source>Window</source>
        <translation>Вікно</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="113"/>
        <source>Screen area</source>
        <translation>Частина екрану</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="155"/>
        <source>Getting new screenshot</source>
        <translation>Отримати новий скріншот</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="158"/>
        <source>New Screen</source>
        <translation>Новий знімок</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="161"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="174"/>
        <source>Delay</source>
        <translation>Затримка</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="193"/>
        <source>Delay in seconds before taking screenshot</source>
        <translation>Затримка в секундах перед отримання скріншоту</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="196"/>
        <source> sec</source>
        <translation> сек</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="218"/>
        <source>Save current screenshot into graphical file</source>
        <translation>Зберегти скріншот в графічний файл</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="221"/>
        <source>Save Screen</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="224"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="243"/>
        <source>Copy current screenshot into clipboard</source>
        <translation>Копіювати скріншот до кишені</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="246"/>
        <source>Copy Screen</source>
        <translation>Копіювати</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="249"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="268"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="300"/>
        <source>Options dialog</source>
        <translation>Параметри програми</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="306"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="325"/>
        <source>Show help information</source>
        <translation>Показати довідкову інформацію</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="328"/>
        <location filename="../src/ui/mainwindow.cpp" line="310"/>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="331"/>
        <source>F1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="350"/>
        <source>Information about ScreenGrab</source>
        <translation>Інформація про програму ScreenGrab</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="356"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="375"/>
        <source>Exit from ScreenGrab</source>
        <translation>Вийти з програми</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="378"/>
        <source>Exit</source>
        <translation>Вихід</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="381"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/core/regionselect.cpp" line="139"/>
        <source>Use your mouse to draw a rectangle to screenshot or exit pressing
any key or using the right or middle mouse buttons.</source>
        <translation>Використовуйте ліву клавішу мишки для виділення частини екрану. 
Клавіатурні клавіші і права кнопка мишки відміняють режим виділення області.</translation>
    </message>
    <message>
        <location filename="../src/core/regionselect.cpp" line="171"/>
        <source>%1 x %2 pixels </source>
        <translation>%1 x %2 піксел </translation>
    </message>
</context>
<context>
    <name>Uploader</name>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="197"/>
        <source>Direct link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="200"/>
        <source>HTML code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="203"/>
        <source>BB code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="206"/>
        <source>HTML code with thumb image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="209"/>
        <source>BB code with thumb image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UploaderConfigWidget</name>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="24"/>
        <source>Common settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="30"/>
        <source>Auto copy result link to clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="39"/>
        <source>Default upload to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="65"/>
        <source>Hosts settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="73"/>
        <source>Settings for: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UploaderConfigWidget_ImgShack</name>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="20"/>
        <source>Account settings for imageshack.us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="32"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="46"/>
        <source>Password: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UploaderConfigWidget_ImgUr</name>
    <message>
        <location filename="../src/modules/uploader/imgur/uploaderconfigwidget_imgur.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgur/uploaderconfigwidget_imgur.ui" line="20"/>
        <source>Configuration for imgur.com upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgur/uploaderconfigwidget_imgur.ui" line="43"/>
        <source>Now is nothing yet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Uploader_ImgShack_Widget</name>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="20"/>
        <source>Upload to imageshack.us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="30"/>
        <source>GroupBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="54"/>
        <source>Resize image: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="65"/>
        <source>No resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="70"/>
        <source>100x75</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="75"/>
        <source>150x112</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="80"/>
        <source>320x240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="85"/>
        <source>640x480</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="90"/>
        <source>800x600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="95"/>
        <source>1024x768</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="100"/>
        <source>1280x1024</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="105"/>
        <source>1600x1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="186"/>
        <source>Anonimus uploading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.cpp" line="12"/>
        <source>Warning!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.cpp" line="13"/>
        <source>Resize makes on servers imageshack.us</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Uploader_ImgUr_Widget</name>
    <message>
        <location filename="../src/modules/uploader/imgur/uploader_imgur_widget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgur/uploader_imgur_widget.ui" line="20"/>
        <source>Upload to ImgUr.com</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>aboutWidget</name>
    <message>
        <location filename="../src/ui/aboutwidget.ui" line="128"/>
        <source>About Qt</source>
        <translation>Про Qt</translation>
    </message>
    <message>
        <location filename="../src/ui/aboutwidget.ui" line="154"/>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
</context>
<context>
    <name>configwidget</name>
    <message>
        <location filename="../src/ui/configwidget.ui" line="26"/>
        <location filename="../src/ui/configwidget.ui" line="667"/>
        <source>Options</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="202"/>
        <source>Default saving image format</source>
        <translation>Формат зображень за замовчанням</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="222"/>
        <source>Default delay before grabbing screen</source>
        <translation>Затримка перед отримання скріншоту</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="324"/>
        <source>Inserting current date time into saved filename</source>
        <translation>Вставка дати та часу в ім&apos;я файлу при збереженні</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="374"/>
        <source>Autosave screenshot</source>
        <translation>Автозберігання скріншотів</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="386"/>
        <source>Save first screenshot</source>
        <translation>Зберігати перший скріншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="89"/>
        <source>Tray</source>
        <translation>Трей</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="99"/>
        <source>Uploader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="263"/>
        <source>Image quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="272"/>
        <source>Image quality (1 - small file, 100 - high quality)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="400"/>
        <source>Filenames to clipboard on saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="414"/>
        <source>No copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="419"/>
        <source>Only filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="424"/>
        <source>Full path to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="615"/>
        <source>Action</source>
        <translation>Дія</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="625"/>
        <source>Global shortcuts</source>
        <translation>Глобальні</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="632"/>
        <source>Fill screen</source>
        <translation>Весь екран</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="637"/>
        <source>Active window</source>
        <translation>Активне вікно</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="642"/>
        <source>Area select</source>
        <translation>Вибрану ділянку</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="652"/>
        <source>New screen</source>
        <translation>Новий скріншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="657"/>
        <source>Save screen</source>
        <translation>Зберегти скріншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="662"/>
        <source>Copy screen</source>
        <translation>Копіювати скріншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="672"/>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="677"/>
        <source>Exit</source>
        <translation type="unfinished">Вихід</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="695"/>
        <source>Not defined</source>
        <translation>Не вибрана</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="734"/>
        <source>Restore default settings</source>
        <translation>Відновити початкові налаштування</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="737"/>
        <source>Defaults</source>
        <translation>За умовчанням</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="763"/>
        <source>Save settings</source>
        <translation>Зберегти налаштування</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="766"/>
        <source>Save</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="779"/>
        <source>Discard changes</source>
        <translation>Закрити без змін</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="782"/>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="74"/>
        <source>Main</source>
        <translation>Головні</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="128"/>
        <source>Default save directory:</source>
        <translation>Тека для збереження:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="137"/>
        <source>Path to default selection dir for saving</source>
        <translation>Шлях до теки для збереження</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="150"/>
        <source>Browse filesystem</source>
        <translation>Огляд файлової системи</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="153"/>
        <source>Browse</source>
        <translation>Огляд</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="171"/>
        <source>Default filename:</source>
        <translation>Вихідне ім&apos;я файлу:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="178"/>
        <source>Default filename</source>
        <translation>Вихідне ім&apos;я файлу</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="189"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="215"/>
        <source>Delay:</source>
        <translation>Затримка:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="228"/>
        <location filename="../src/ui/configwidget.ui" line="564"/>
        <source> sec</source>
        <translation> сек</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="254"/>
        <source>No window decoration</source>
        <translation>Без декорацій вікна</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="79"/>
        <source>Advanced</source>
        <translation>Розширені</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="327"/>
        <source>Insert DateTime in filename</source>
        <translation>Вставляти дату та час в ім&apos;я файлу</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="336"/>
        <source>Template: </source>
        <translation>Шаблон: </translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="361"/>
        <source>Example: </source>
        <translation>Приклад: </translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="371"/>
        <source>Automaticaly saving screenshots in grabbing process</source>
        <translation>Автоматичне збереження скріншотів при їх отриманні</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="84"/>
        <source>Display</source>
        <translation>Відображення</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="497"/>
        <source>Use tray</source>
        <translation>Використовувати трей</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="506"/>
        <source>Tray messages:</source>
        <translation>Спливаючі повідомлення:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="519"/>
        <source>Tray messages display mode</source>
        <translation>Режим відображення спливаючих повідомлень</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="523"/>
        <source>Never</source>
        <translation>Ніколи</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="528"/>
        <source>Tray mode</source>
        <translation>Якщо згорнуто</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="533"/>
        <source>Always</source>
        <translation>Завжди</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="94"/>
        <source>Shortcuts</source>
        <translation>Комбінації клавіш</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="620"/>
        <source>Shortcut</source>
        <translation>Клавіші</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="648"/>
        <source>Local shortcutss</source>
        <translation>Локальні</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="688"/>
        <source>Selected shortcut:</source>
        <translation>Вибрана комбінація:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="461"/>
        <source>Saving main window size on exit</source>
        <translation>Збереження розмірів вікна програми при виході</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="464"/>
        <source>Save window size on exit</source>
        <translation>Зберігати розмір вікна при виході</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="545"/>
        <source>Time of display tray messages</source>
        <translation>Час показу спливаючих повідомлень</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="561"/>
        <source>Time to display tray messages</source>
        <translation>Час показу спливаючих повідомлень</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="471"/>
        <source>Zoom area around mouse in selection mode</source>
        <translation>Масштаб області курсора в режимі вибору</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="582"/>
        <source>Minimize in tray on click close button</source>
        <translation>Ховатись в трей при закритті</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="585"/>
        <source>Close in tray</source>
        <translation>Закривати в трей</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="434"/>
        <source>Allow run multiplies copy of Screen Grab</source>
        <translation>Дозволити запуск кількох копій програми</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="437"/>
        <source>Allow multiple copies</source>
        <translation>Кілька копій програми</translation>
    </message>
</context>
</TS>
