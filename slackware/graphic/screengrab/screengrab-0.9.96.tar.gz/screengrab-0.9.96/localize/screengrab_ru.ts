<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/ui/about.cpp" line="37"/>
        <source>built on </source>
        <translation>дата сборки </translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="42"/>
        <source>using Qt </source>
        <translation>использует Qt </translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="53"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="54"/>
        <source>Thanks</source>
        <translation>Благодарности</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="111"/>
        <source>is crossplatform application for fast creation screenshots of your desktop.</source>
        <translation>кроссплатформенное приложение для быстрого создания скриншотов.</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="123"/>
        <source>Licensed under the </source>
        <translation>Лицензировано по </translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="116"/>
        <location filename="../src/ui/about.cpp" line="145"/>
        <source>E-Mail</source>
        <translation>Электронная почта</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="55"/>
        <source>Help us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="113"/>
        <source>It&apos;s a light and powerfull application and had been written using Qt, so you can to use in Windows and Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="119"/>
        <source>Web site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="127"/>
        <source>Copyright &amp;copy; 2009-2012, Artem &apos;DOOMer&apos; Galichkin</source>
        <translation type="unfinished">Copyright &amp;copy; 2009-2010, Артём &apos;DOOMer&apos; Галичкин {2009-2012,?}</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="134"/>
        <source>You can join us and help us if you want, is an invitation if you like this application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="137"/>
        <source>What you can do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="140"/>
        <source>Translate to other language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="141"/>
        <source>Make suggestions for next releases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="142"/>
        <source>Report bugs and issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="149"/>
        <source>Bug tracker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="159"/>
        <source>Translate:</source>
        <translation>Переводы:</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="161"/>
        <source> Brazilian Portuguese translation</source>
        <translation>Бразильская Португальская локализация</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="162"/>
        <source>Marcio Moraes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="164"/>
        <source> Ukrainian translation</source>
        <translation>Украинская локализация</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="165"/>
        <source>Gennadi Motsyo</source>
        <translation>Геннадий Моцьо</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="167"/>
        <source> Spanish translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="168"/>
        <source>Burjans L GarcÃ­a D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="170"/>
        <source> Italian translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="174"/>
        <source>Testing:</source>
        <translation>Тестирование:</translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="176"/>
        <source>Dual monitor support and other in Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="177"/>
        <source>Dual monitor support in Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="178"/>
        <source>win32-build [Windows XP and 7]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="179"/>
        <source>old win32-build [Windows Vista]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/about.cpp" line="180"/>
        <source>win32-build [Windows 7]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigDialog</name>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="323"/>
        <location filename="../src/ui/configwidget.cpp" line="332"/>
        <source>Select directory</source>
        <translation>Выбор каталога</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="345"/>
        <source>Do you want reset settings to defaults?</source>
        <translation>Вы хотите установить настройки в значения по умолчанию?</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="228"/>
        <location filename="../src/ui/configwidget.cpp" line="346"/>
        <source>Warning</source>
        <translation>Предупрждение</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="227"/>
        <source>Directory %1 does not exists. Do you eant to create it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="364"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="412"/>
        <source>Example: </source>
        <translation>Пример: </translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="473"/>
        <source>This keys is used in your system! Please select other keys</source>
        <translation>Эта комбинация клавиш уже используется  в вашей системе!  Выберите другую.</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="481"/>
        <source>This keys is used in ScreenGrab! Please select other keys</source>
        <translation>Эта комбинация клавиш уже используется в  ScreenGrab!  Выберите другую.</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="501"/>
        <source>This key is not supported on your system!</source>
        <translation>Эта комбинация не поддерживается вашей системой!</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.cpp" line="538"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../src/core/core.cpp" line="183"/>
        <source>New screen</source>
        <translation>Новый скриншот</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="183"/>
        <source>New screen is getted!</source>
        <translation>Получен новый скриншот</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="400"/>
        <source>Saved</source>
        <translation>Сохранено</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="432"/>
        <source>Name of saved file is copied to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="438"/>
        <source>Path to saved file is copyed to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="451"/>
        <source>Copied</source>
        <translation>Скопировано</translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="400"/>
        <source>Saved to </source>
        <translation>Слхранено в </translation>
    </message>
    <message>
        <location filename="../src/core/core.cpp" line="451"/>
        <source>Screenshot is copied to clipboard</source>
        <translation>Скриншот скопирован в буфер обмена</translation>
    </message>
</context>
<context>
    <name>DialogUploader</name>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="14"/>
        <source>Publish to internet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="22"/>
        <source>Upload to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="73"/>
        <source>Direct link:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="95"/>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="133"/>
        <source>Copy</source>
        <translation type="unfinished">Копировать</translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="106"/>
        <source>Extended preformed html or bb codes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="183"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="241"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.ui" line="254"/>
        <source>Close</source>
        <translation type="unfinished">Закрыть</translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="54"/>
        <source>Size: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="54"/>
        <source> pixel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="63"/>
        <source>Uploaded </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="66"/>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="212"/>
        <source>Ready to upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="106"/>
        <source>Upload preocessing... Please wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="170"/>
        <source>Receiving a response from the server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="192"/>
        <source>Upload completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="206"/>
        <source>Error uploading screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/dialoguploader.cpp" line="207"/>
        <source>Error</source>
        <translation type="unfinished">Ошибка</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="303"/>
        <source>Quit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="304"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="305"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="306"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="307"/>
        <location filename="../src/ui/mainwindow.cpp" line="438"/>
        <location filename="../src/ui/mainwindow.cpp" line="468"/>
        <source>Hide</source>
        <translation>Скрыть окно</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="353"/>
        <location filename="../src/ui/mainwindow.cpp" line="308"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="558"/>
        <source>PNG Files</source>
        <translation>файлы PNG</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="559"/>
        <source>JPEG Files</source>
        <translation>файлы JPEG</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="560"/>
        <source>BMP Files</source>
        <translation>файлы BMP</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="303"/>
        <location filename="../src/ui/mainwindow.cpp" line="309"/>
        <source>Options</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="372"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="445"/>
        <source>Show</source>
        <translation>Показать окно</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.cpp" line="591"/>
        <location filename="../src/ui/mainwindow.cpp" line="595"/>
        <location filename="../src/ui/mainwindow.cpp" line="599"/>
        <source>Save As...</source>
        <translation>Сохранить как...</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="20"/>
        <source>ScreenGrab</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="83"/>
        <source>Type: </source>
        <translation>Тип: </translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="96"/>
        <source>Type of screenshot</source>
        <translation>Тип скриншота</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="103"/>
        <source>Full screen</source>
        <translation>Весь экран</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="108"/>
        <source>Window</source>
        <translation>Окно</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="113"/>
        <source>Screen area</source>
        <translation>Область экрана</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="155"/>
        <source>Getting new screenshot</source>
        <translation>Получить новый скриншот</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="158"/>
        <source>New Screen</source>
        <translation>Новый снимок</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="161"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="174"/>
        <source>Delay</source>
        <translation>Задержка</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="193"/>
        <source>Delay in seconds before taking screenshot</source>
        <translation>Задержка в секундах перед получением скриншота</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="196"/>
        <source> sec</source>
        <translation> сек</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="218"/>
        <source>Save current screenshot into graphical file</source>
        <translation>Сохранить скриншот в графический файл</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="221"/>
        <source>Save Screen</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="224"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="243"/>
        <source>Copy current screenshot into clipboard</source>
        <translation>Копировать скриншот в буфер обмена</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="246"/>
        <source>Copy Screen</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="249"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="268"/>
        <source>Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="300"/>
        <source>Options dialog</source>
        <translation>Настрйоки программы</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="306"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="325"/>
        <source>Show help information</source>
        <translation>Показать справочную информацию</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="328"/>
        <location filename="../src/ui/mainwindow.cpp" line="310"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="331"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="350"/>
        <source>Information about ScreenGrab</source>
        <translation>Информация о программе  ScreenGrab</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="356"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="375"/>
        <source>Exit from ScreenGrab</source>
        <translation>Выход из программы</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="378"/>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="../src/ui/mainwindow.ui" line="381"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/core/regionselect.cpp" line="139"/>
        <source>Use your mouse to draw a rectangle to screenshot or exit pressing
any key or using the right or middle mouse buttons.</source>
        <translation>Используйте левую клавишу мыши для выделения области экрана. 
Клавиатурные клавиши и правая кнопка мыши отменяют режим выделения области.</translation>
    </message>
    <message>
        <location filename="../src/core/regionselect.cpp" line="171"/>
        <source>%1 x %2 pixels </source>
        <translation>%1 x %2 пиксел </translation>
    </message>
</context>
<context>
    <name>Uploader</name>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="197"/>
        <source>Direct link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="200"/>
        <source>HTML code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="203"/>
        <source>BB code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="206"/>
        <source>HTML code with thumb image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploader.cpp" line="209"/>
        <source>BB code with thumb image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UploaderConfigWidget</name>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="24"/>
        <source>Common settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="30"/>
        <source>Auto copy result link to clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="39"/>
        <source>Default upload to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="65"/>
        <source>Hosts settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/uploaderconfigwidget.ui" line="73"/>
        <source>Settings for: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UploaderConfigWidget_ImgShack</name>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="20"/>
        <source>Account settings for imageshack.us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="32"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploaderconfigwidget_imgshack.ui" line="46"/>
        <source>Password: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UploaderConfigWidget_ImgUr</name>
    <message>
        <location filename="../src/modules/uploader/imgur/uploaderconfigwidget_imgur.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgur/uploaderconfigwidget_imgur.ui" line="20"/>
        <source>Configuration for imgur.com upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgur/uploaderconfigwidget_imgur.ui" line="43"/>
        <source>Now is nothing yet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Uploader_ImgShack_Widget</name>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="20"/>
        <source>Upload to imageshack.us</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="30"/>
        <source>GroupBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="54"/>
        <source>Resize image: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="65"/>
        <source>No resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="70"/>
        <source>100x75</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="75"/>
        <source>150x112</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="80"/>
        <source>320x240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="85"/>
        <source>640x480</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="90"/>
        <source>800x600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="95"/>
        <source>1024x768</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="100"/>
        <source>1280x1024</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="105"/>
        <source>1600x1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.ui" line="186"/>
        <source>Anonimus uploading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.cpp" line="12"/>
        <source>Warning!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgshack/uploader_imgshack_widget.cpp" line="13"/>
        <source>Resize makes on servers imageshack.us</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Uploader_ImgUr_Widget</name>
    <message>
        <location filename="../src/modules/uploader/imgur/uploader_imgur_widget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/modules/uploader/imgur/uploader_imgur_widget.ui" line="20"/>
        <source>Upload to ImgUr.com</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>aboutWidget</name>
    <message>
        <location filename="../src/ui/aboutwidget.ui" line="128"/>
        <source>About Qt</source>
        <translation>О библиотеке Qt</translation>
    </message>
    <message>
        <location filename="../src/ui/aboutwidget.ui" line="154"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>configwidget</name>
    <message>
        <location filename="../src/ui/configwidget.ui" line="26"/>
        <location filename="../src/ui/configwidget.ui" line="667"/>
        <source>Options</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="202"/>
        <source>Default saving image format</source>
        <translation>Формат скриншотов по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="222"/>
        <source>Default delay before grabbing screen</source>
        <translation>Задержка перед получением скриншота</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="324"/>
        <source>Inserting current date time into saved filename</source>
        <translation>Вставка даты и времени в имя сохраняемого файла</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="374"/>
        <source>Autosave screenshot</source>
        <translation>Австосохранение скриншота</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="386"/>
        <source>Save first screenshot</source>
        <translation>Сохранять первый сриншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="89"/>
        <source>Tray</source>
        <translation>Трей</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="99"/>
        <source>Uploader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="263"/>
        <source>Image quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="272"/>
        <source>Image quality (1 - small file, 100 - high quality)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="400"/>
        <source>Filenames to clipboard on saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="414"/>
        <source>No copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="419"/>
        <source>Only filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="424"/>
        <source>Full path to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="615"/>
        <source>Action</source>
        <translation>Действие</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="625"/>
        <source>Global shortcuts</source>
        <translation>Глобальные</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="632"/>
        <source>Fill screen</source>
        <translation>Весь экран</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="637"/>
        <source>Active window</source>
        <translation>Активное окно</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="642"/>
        <source>Area select</source>
        <translation>Выбранная область</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="652"/>
        <source>New screen</source>
        <translation>Новый скриншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="657"/>
        <source>Save screen</source>
        <translation>Сохранить скриншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="662"/>
        <source>Copy screen</source>
        <translation>Копировать скриншот</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="672"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="677"/>
        <source>Exit</source>
        <translation type="unfinished">Выход</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="695"/>
        <source>Not defined</source>
        <translation>Не определена</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="734"/>
        <source>Restore default settings</source>
        <translation>Восстановить исходные настройки</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="737"/>
        <source>Defaults</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="763"/>
        <source>Save settings</source>
        <translation>Сохранить настройки</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="766"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="779"/>
        <source>Discard changes</source>
        <translation>Закрыть без изменений</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="782"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="74"/>
        <source>Main</source>
        <translation>Основные</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="128"/>
        <source>Default save directory:</source>
        <translation>Исходный каталог:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="137"/>
        <source>Path to default selection dir for saving</source>
        <translation>Исходный каталог для сохраняемых файлов</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="150"/>
        <source>Browse filesystem</source>
        <translation>Обзор файловой системы</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="153"/>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="171"/>
        <source>Default filename:</source>
        <translation>Исходное имя файла:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="178"/>
        <source>Default filename</source>
        <translation>Имя файла по умолчанию</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="189"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="215"/>
        <source>Delay:</source>
        <translation>Задержка:</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="228"/>
        <location filename="../src/ui/configwidget.ui" line="564"/>
        <source> sec</source>
        <translation> сек</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="254"/>
        <source>No window decoration</source>
        <translation>Без декораций окна</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="79"/>
        <source>Advanced</source>
        <translation>Расширенные</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="327"/>
        <source>Insert DateTime in filename</source>
        <translation>Вставлять дату и время в имя файла</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="336"/>
        <source>Template: </source>
        <translation>Шаблон: </translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="361"/>
        <source>Example: </source>
        <translation>Пример: </translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="371"/>
        <source>Automaticaly saving screenshots in grabbing process</source>
        <translation>Автоматическое сохранение скриншотов при их получении</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="84"/>
        <source>Display</source>
        <translation>Отображение</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="497"/>
        <source>Use tray</source>
        <translation>Использовать трей</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="506"/>
        <source>Tray messages:</source>
        <translation>Всплывающие уведомления</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="519"/>
        <source>Tray messages display mode</source>
        <translation>Режим отображения всплывающих уведомлений</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="523"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="528"/>
        <source>Tray mode</source>
        <translation>Если свёрнуто</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="533"/>
        <source>Always</source>
        <translation>Всегда</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="94"/>
        <source>Shortcuts</source>
        <translation>Комбинации клавиш</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="620"/>
        <source>Shortcut</source>
        <translation>Клавиши</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="648"/>
        <source>Local shortcutss</source>
        <translation>Локальные</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="688"/>
        <source>Selected shortcut:</source>
        <translation>Выбранная комбинация</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="461"/>
        <source>Saving main window size on exit</source>
        <translation>Сохранение размеров окна программы при выходе</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="464"/>
        <source>Save window size on exit</source>
        <translation>Сохранять размер окна при выходе</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="545"/>
        <source>Time of display tray messages</source>
        <translation>Время отображения всплывающих уведомлений</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="561"/>
        <source>Time to display tray messages</source>
        <translation>Время отображения всплывающих уведомлений</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="471"/>
        <source>Zoom area around mouse in selection mode</source>
        <translation>Масштабирование области курсора в режиме выбора</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="582"/>
        <source>Minimize in tray on click close button</source>
        <translation>Сворачивать в область уведомлений при использовании кнопки закрытия</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="585"/>
        <source>Close in tray</source>
        <translation>Сворачивать в область уведомлений</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="434"/>
        <source>Allow run multiplies copy of Screen Grab</source>
        <translation>Позволять запуск нескольких копий программы</translation>
    </message>
    <message>
        <location filename="../src/ui/configwidget.ui" line="437"/>
        <source>Allow multiple copies</source>
        <translation>Несколько копий программы</translation>
    </message>
</context>
</TS>
