#!/bin/sh
export ANT_HOME=/usr/lib/ant
export PATH="${PATH}:/usr/lib/ant/bin"
